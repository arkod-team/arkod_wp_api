=== Arkod WP ===
Contributors: l.gilhard@arkod.fr
Tags: arkod, wordpress, arkod-wp
License: MIT

Plugin used by ArkodWP to run operations on websites. It's mainly useful to configure plugins which doesn't provide any API.

== Description ==

Arkod WP is a plugin extending WordPress API to run PHP functions on websites from ArkodWP. It's mainly useful to configure plugins which doesn't provide any API.

== API reference ==

**Base URL**
`<your-website-url>/wp-json/arkod-wp/v1`

**Headers requirement**
- `Content-Type: application/json`

= Oxygen =

- **Add design set**

  [POST] `/oxygen/design-set`
  
  Add an Oxygen design set. Set up Oxygen if needed. Enable 3rd-party design sets if not enabled before adding given design set. 
  - **Body parameters**
    - `design-set` : Key of the design set to add.
  - **Errors**
    - `[404] no-oxygen` : Oxygen is not installed and actived
    - `[400] invalid-design-set-key` : Provided design set key is invalid
    - `[400] existing-design-set` : A design set with the same title or URL already exists
    - `[xxx] design-set-unavailable` : Access to the design set sources failed
    - `[503] design-set-access-denied` : Access to the design set sources is denied
