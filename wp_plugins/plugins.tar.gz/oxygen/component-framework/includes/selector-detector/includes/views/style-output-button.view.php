<div class="oxygen-selector-detector-style-button"
	ng-show="!iframeScope.selectorDetector.mode"
	ng-click="$parent.enableSelectorDetectorMode()">
	<?php _e("Style Output", "oxygen"); ?>
</div>